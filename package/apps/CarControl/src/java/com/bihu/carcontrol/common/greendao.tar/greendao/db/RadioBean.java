package com.bihu.carcontrol.common.greendao.db;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Keep;
import org.greenrobot.greendao.annotation.Property;

/**
 * FileName: RadioBena
 * Author: WangXu
 * Date: 2023/8/2 10:32
 * Description:
 */
@Entity(nameInDb = "DB_RADIO")
public class RadioBean {
    @Id(autoincrement = true)
    @Property(nameInDb = "ID")
    public Long id;
    @Property(nameInDb = "IS_COLLECT")
    public boolean isCollect = false;
    @Property(nameInDb = "FM_NUM")
    public double fmNum;
    @Property(nameInDb = "IS_PLAY")
    public boolean isPlay = false;
    @Property(nameInDb = "IS_PAUSE")
    public boolean isPause = false;
    @Property(nameInDb = "ASSET_URL")
    public String assetUrl;

    public RadioBean(boolean isCollect, double fmNum, boolean isPlay) {
        this.isCollect = isCollect;
        this.fmNum = fmNum;
        this.isPlay = isPlay;
    }

    public RadioBean(boolean isCollect, double fmNum, boolean isPlay, String assetUrl) {
        this.isCollect = isCollect;
        this.fmNum = fmNum;
        this.isPlay = isPlay;
        this.assetUrl = assetUrl;
    }

    @Keep
    public RadioBean(Long id, boolean isCollect, double fmNum, boolean isPlay,
                     boolean isPause, String assetUrl) {
        this.id = id;
        this.isCollect = isCollect;
        this.fmNum = fmNum;
        this.isPlay = isPlay;
        this.isPause = isPause;
        this.assetUrl = assetUrl;
    }

    @Generated(hash = 200470621)
    public RadioBean() {
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public boolean getIsCollect() {
        return this.isCollect;
    }

    public void setIsCollect(boolean isCollect) {
        this.isCollect = isCollect;
    }

    public double getFmNum() {
        return this.fmNum;
    }

    public void setFmNum(double fmNum) {
        this.fmNum = fmNum;
    }

    public boolean getIsPlay() {
        return this.isPlay;
    }

    public void setIsPlay(boolean isPlay) {
        this.isPlay = isPlay;
    }

    public boolean getIsPause() {
        return this.isPause;
    }

    public void setIsPause(boolean isPause) {
        this.isPause = isPause;
    }

    public String getAssetUrl() {
        return this.assetUrl;
    }

    public void setAssetUrl(String assetUrl) {
        this.assetUrl = assetUrl;
    }
}
